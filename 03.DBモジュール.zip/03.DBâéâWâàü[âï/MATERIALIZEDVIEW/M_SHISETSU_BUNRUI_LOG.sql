create materialized view log on M_SHISETSU_BUNRUI
with ROWID ,PRIMARY KEY,sequence
including new values
/

