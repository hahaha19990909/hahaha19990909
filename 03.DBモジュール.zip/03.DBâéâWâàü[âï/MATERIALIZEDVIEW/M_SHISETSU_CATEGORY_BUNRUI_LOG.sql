create materialized view log on M_SHISETSU_CATEGORY_BUNRUI
with ROWID ,PRIMARY KEY,sequence
including new values
/

