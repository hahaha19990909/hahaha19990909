create materialized view log on M_SHISETSU_CATEGORY
with ROWID ,PRIMARY KEY,sequence
including new values
/

