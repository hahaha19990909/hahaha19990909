CREATE MATERIALIZED VIEW M_SHISETSU_CATEGORY_BUNRUI
REFRESH FAST ON DEMAND
NEXT trunc(sysdate) + 2 + 1/24
AS
select C.ROWID as c_rowid,
	D.ROWID as d_rowid,
	D.DATA_CD,
	C.CATEGORY_ID,
	C.BUNRUI_CD,
	C.CATEGORY_NAME,
	C.SORT_NO
from M_SHISETSU_CATEGORY@HOMEMATE_DB.WORLD C,
	M_SHISETSU_CATEGORY_BUNRUI@HOMEMATE_DB.WORLD D
where C.CATEGORY_ID = D.CATEGORY_ID
and C.BUNRUI_CD = D.BUNRUI_CD
and C.LOGICAL_DEL_FLG = '0'
and D.LOGICAL_DEL_FLG = '0'
and C.BUNRUI_CD IN ('15', --保育園,保育所
	'80',	--幼稚園
	'31',	--小学校
	'61',	--中学校
	'62',	--高校
	'63',	--高専学校
	'12',	--短期大学
	'11',	--大学
--	'103',	--大学院
	'13',	--専門学校
	'06',	--病院・総合病院
--	'57',	--大学病院
	'25',	--医院・クリニック・診療所
--	'60',	--歯科病院・総合病院
	'56',	--市役所
	'09',	--区役所
	'10',	--町村役場
	'38',	--都道府県庁
	'112'	--デパート
	)
/


CREATE INDEX IDX_M_SHISETSU_CATE_BUNRUI_001
	ON M_SHISETSU_CATEGORY_BUNRUI (BUNRUI_CD, DATA_CD) 
	TABLESPACE CHUKAI_IDX LOGGING PCTFREE 10 INITRANS 2 MAXTRANS 255 
		STORAGE(INITIAL 64K NEXT 0M MINEXTENTS 1 MAXEXTENTS UNLIMITED  
			BUFFER_POOL DEFAULT ) 
/

