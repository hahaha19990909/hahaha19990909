create materialized view log on M_SHISETSU
with ROWID ,PRIMARY KEY,sequence
including new values
/

