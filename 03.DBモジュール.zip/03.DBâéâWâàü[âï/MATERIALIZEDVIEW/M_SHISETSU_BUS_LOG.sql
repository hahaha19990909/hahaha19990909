create materialized view log on M_SHISETSU_BUS
with ROWID ,PRIMARY KEY,sequence
--with ROWID ,sequence (DATA_CD, CATEGORY_ID, MUKI, STOP_SEQ)
including new values
/

